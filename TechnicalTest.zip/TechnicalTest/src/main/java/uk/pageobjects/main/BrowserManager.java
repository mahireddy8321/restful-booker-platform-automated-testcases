package uk.pageobjects.main;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserManager {
	
	private static WebDriver driver;
	
	public static WebDriver driver(String url){
		
			File file = new File("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
			System.setProperty("webdriver.firefox.bin",  file.getAbsolutePath());	
			driver = new FirefoxDriver();
			driver.get(url);
			return driver;
	}
	
	public static void closebrowser(){
		driver.quit();
	}
	
	public static void cleanUpBrowsers() {
		if(driver!=null)		
			driver.close();
	}
	
	
}
