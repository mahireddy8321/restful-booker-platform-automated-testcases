# Automated Test Cases for restful-booker-platform
- Created Automated test cases for below
  Create an Entry
  Delete an Entry
  Creation of Multiple Entries

# Setup and Running
1. Clone the repo
2. Unzip the folder TechnicalTest
3. Import the folder TechnicalTest as a Maven Project
4. Navigate to TechnicalTest/src/test/java/uk/pageobjects/main/TestRunner.java file
5. Right click and select 'Run As' and 'JUnit Test'
6. This will run below tests
    Create an Entry
    Delete an Entry
    Creation of Multiple Entries
