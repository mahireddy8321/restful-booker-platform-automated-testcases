package uk.pageobjects.main;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class HMLoginPage extends Common{

	public void login(WebDriver driver){
		driver.navigate().to("http://localhost:3003/");
		clickWhenReady(driver,By.linkText("Login"),30);
		getWhenVisible(driver,By.id("username"),30).sendKeys("admin");
		getWhenVisible(driver,By.id("password"),30).sendKeys("password");
		driver.findElement(By.id("doLogin")).click();
	}
	
	

}
