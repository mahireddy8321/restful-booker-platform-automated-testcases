package uk.pageobjects.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CreateDeletePage extends HMLoginPage{
	
	
	public static void createEntry(WebDriver driver, String Hotelname, String address, String ownerdetails, String PhoneNumber){
		driver.findElement(By.id("hotelname")).sendKeys(Hotelname);
		driver.findElement(By.id("address")).sendKeys(address);
		driver.findElement(By.id("owner")).sendKeys(ownerdetails);
		driver.findElement(By.id("phonenumer")).sendKeys(PhoneNumber);
		driver.findElement(By.id("createHotel")).click();
	}


	public static void deleteEntry(WebDriver driver){
			driver.findElement(By.id("deleteImg")).click();
	}
	
	public static void multipleEntry(int entries){
		
		int i;
		for (i=0;i<entries;i++)
		{
			createEntry(null, "HotelName"+i, "Address"+i, "Owner"+i, "Phonenumer"+i);
		}
		
	}
	public static void main(String[] args) {
		multipleEntry(3);
	}
}
