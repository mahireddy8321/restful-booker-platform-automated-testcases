package uk.pageobjects.main;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeSuite;

import uk.pageobjects.main.BrowserManager;
import uk.pageobjects.main.CreateDeletePage;
import uk.pageobjects.main.HMLoginPage;

public class NewTest {
  
  @Test
  public void LoginPage() {
	  HMLoginPage login = new HMLoginPage();
	  login.login(driver); 
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @BeforeTest
  public void beforeTest() {
	  
	  BrowserManager bm = new BrowserManager();
	  bm.driver();
  }
 

  @BeforeSuite
  public void beforeSuite() {
  }

}
