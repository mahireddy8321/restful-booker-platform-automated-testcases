package uk.pageobjects.main;

import org.junit.Test;

public class TestRunner {
	
	
	@Test
	public void createBrowser(){
		BrowserManager.driver("http://localhost:3003");
	}
	
	@Test
	public void createEntry(){
		CreateDeletePage.createEntry(null, "Premier inn", "Test Address", "Owner", "0000000000");
	}
	
	@Test
	public void deleteEntry(){
		CreateDeletePage.deleteEntry(null);
	}
	
	@Test
	public void multipleEntry(){
		CreateDeletePage.multipleEntry(5);
	}
	
	@Test
	public void CloseBrowser(){
		BrowserManager.closebrowser();
		//BrowserManager.cleanUpBrowsers();
	}
	

}
